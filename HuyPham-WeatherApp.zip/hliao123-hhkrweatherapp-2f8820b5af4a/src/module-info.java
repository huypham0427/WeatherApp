module HHKRapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;

    opens sample;
}