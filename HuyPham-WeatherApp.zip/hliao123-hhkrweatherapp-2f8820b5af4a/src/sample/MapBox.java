package sample;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class MapBox {
    private String query;
    private JsonElement forecast;

    public MapBox (String kw){
        query = kw;
        String getPlace = "";
        if (query.matches("[0-9]+")) {
            query = query.replace(" ", "%20");

                getPlace = "https://api.mapbox.com/geocoding/v5/mapbox.places/"
                    + query
                    + ".json?access_token=pk.eyJ1Ijoic2llcnJhY3MiLCJhIjoiY2p2YWExN3NwMGQ3aTQxbzAxZnh6YzloMiJ9.BL6OLkhv0rHoKtMnL_kEkA&limit=10&types=postcode";
        }
        else{
            query = query.replace("", "");
                 getPlace = "https://api.mapbox.com/geocoding/v5/mapbox.places/"
                    + query
                    + ".json?access_token=pk.eyJ1Ijoic2llcnJhY3MiLCJhIjoiY2p2YWExN3NwMGQ3aTQxbzAxZnh6YzloMiJ9.BL6OLkhv0rHoKtMnL_kEkA&limit=10&types=place";
        }

        try {
            URL url = new URL(getPlace);
            InputStream is = url.openStream();
            InputStreamReader isr = new InputStreamReader(is);

            /*Parse JSON HERE*/

            forecast = JsonParser.parseReader(isr);
        } catch (
                MalformedURLException mue) {
            System.out.println("Malformed URL");
            mue.printStackTrace();
        } catch (
                IOException ioe) {
            System.out.println("IO Exception");
            ioe.printStackTrace();
        }

    }

    public String getmapBox(int num){
        return forecast.getAsJsonObject()
            .get("features").getAsJsonArray()
            .get(num).getAsJsonObject()
            .get("place_name").getAsString();
    }

    public String getCenter(int num){
        double Lat= forecast.getAsJsonObject()
                .get("features").getAsJsonArray()
                .get(num).getAsJsonObject()
                .get("center").getAsJsonArray()
                .get(0).getAsDouble();
        double Long= forecast.getAsJsonObject()
                .get("features").getAsJsonArray()
                .get(num).getAsJsonObject()
                .get("center").getAsJsonArray()
                .get(1).getAsDouble();
        return Long + "," + Lat;
    }

    public int getSize(){
        return forecast.getAsJsonObject()
                .get("features").getAsJsonArray().size();
    }


}
