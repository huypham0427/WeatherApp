package sample;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.TimeZone;

public class Weather {
    Weather w;
    private String kwZip;
    private String kwCity;
    private static JsonElement forecast;
    String clientID = "VHSQboCdrEwPFpuUTMYpk";
    String clientSecret = "skRaav9bMvcI7J44GWZKh4BAptXAa0SxGHmLeWo6";


    public Weather(String kw)
    {
        if (kw.equals("")){
            kw = ":auto";
        }
        try
        {
            kwZip = URLEncoder.encode(kw, "utf-8");
            kwCity = URLEncoder.encode(kw, "utf-8");
        }
        catch (UnsupportedEncodingException uee)
        {
            uee.printStackTrace();
        }
    }


    public void fetch()
    {

        String zipKey = "https://api.aerisapi.com/observations/"
                + kwZip
                + "?client_id=" + clientID
                + "&client_secret="+ clientSecret;


        try
        {
            URL url = new URL(zipKey);
            InputStream is = url.openStream();
            InputStreamReader isr = new InputStreamReader(is);

            /*Parse JSON HERE*/

            forecast = JsonParser.parseReader(isr);
        }
        catch (MalformedURLException mue)
        {
            System.out.println("Malformed URL");
            mue.printStackTrace();
        }
        catch (IOException ioe)
        {
            System.out.println("IO Exception");
            ioe.printStackTrace();
        }



    }
    public String getWeather()
    {
        String city = "";
        return forecast.getAsJsonObject().get("response").getAsJsonObject().get("ob").getAsJsonObject().get("weather").getAsString();
        //return city;
    }
    public String getIcon()
    {
        String icon = "";
        icon = forecast.getAsJsonObject().get("response").getAsJsonObject().get("ob").getAsJsonObject().get("icon").getAsString();
        return icon;
    }
     public String getCityState()
    {

        String city = "";
         city = forecast.getAsJsonObject().get("response").getAsJsonObject().get("place").getAsJsonObject().get("name").getAsString();

        String state = "";
        state = forecast.getAsJsonObject().get("response").getAsJsonObject().get("place").getAsJsonObject().get("state").getAsString();

        String country = "";
        country = forecast.getAsJsonObject().get("response").getAsJsonObject().get("place").getAsJsonObject().get("country").getAsString();
        return city.toUpperCase() + ", " + state.toUpperCase() + " " + country.toUpperCase()+"A";

    }




    public static TimeZone getTimeZone() {

    return TimeZone.getTimeZone(forecast.getAsJsonObject().get("response").getAsJsonObject().get("ob").getAsJsonObject().get("tzname").getAsString());

    }



    public static String getTimeStamp()
    {

        String timeZone = "";
        Date currentDate = new Date();

        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMM d, yyyy h:mm a");


        return dateFormat.format(currentDate);
    }


    public double getTemperature()
    {
        double tempF = 0;
        tempF = forecast.getAsJsonObject().get("response").getAsJsonObject().get("ob").
            getAsJsonObject().get("tempF").getAsDouble();
        return tempF;
    }
    public double getWindSpeed()
    {
        double windMPH = 0;
        windMPH = forecast.getAsJsonObject().get("response").getAsJsonObject().get("ob").
                getAsJsonObject().get("windSpeedMPH").getAsDouble();
        return windMPH;
    }

    public double getCelsius()
    {
        double tempC = 0;
        tempC = forecast.getAsJsonObject().get("response").getAsJsonObject().get("ob").
                getAsJsonObject().get("tempC").getAsDouble();
        return tempC;
    }


//    public boolean isSuccessful() {
//
//        String fetchSuccess = forecast.getAsJsonObject().get("success").getAsString();
//
//        String map = "";
//
//        String longitude = "", latitude = "";
//
//        if (fetchSuccess.equals("true"))
//        {
//            longitude = forecast.getAsJsonObject().get("response").getAsJsonObject().get("loc").
//                    getAsJsonObject().get("long").getAsString();
//
//            latitude  = forecast.getAsJsonObject().get("response").getAsJsonObject().get("loc").
//                    getAsJsonObject().get("lat").getAsString();
//        }
//        else {longitude = "";
//            latitude = "";
//            String empty = " ";
//    }


    public String getMap()
    {
        String map = "";

        String longitude = "", latitude = "";

        String fetchSuccess = forecast.getAsJsonObject().get("success").getAsString();

        if (fetchSuccess.equals("true"))
        {
            longitude = forecast.getAsJsonObject().get("response").getAsJsonObject().get("loc").
                    getAsJsonObject().get("long").getAsString();

            latitude  = forecast.getAsJsonObject().get("response").getAsJsonObject().get("loc").
                    getAsJsonObject().get("lat").getAsString();
        }
        else {
            longitude = "";
            latitude = "";
        }
            /*mapicon.setVisible(false)*/;
       /* !w.getCityState();*/


   /*     else
        {*/
            // get the local-area map via the local longitude/latitude obtained from the client IP address

                    //need to pull (fetch) from the forecast JSON object, NOTE the ipinfo.io
  /*          try
            {
                URL url1 = new URL("http://ipinfo.io");
                InputStream stream = url1.openStream();
                InputStreamReader streamReader = new InputStreamReader(stream);

                *//*Parse JSON HERE*//*

                JsonElement localIp = JsonParser.parseReader(streamReader);

                String location[]= localIp.getAsJsonObject().get("loc").getAsString().split(",");

                longitude = location[1];

                latitude  = location[0];
            }
            catch (MalformedURLException mue)
            {
                System.out.println("Malformed URL");
                mue.printStackTrace();
            }
            catch (IOException ioe)
            {
                System.out.println("IO Exception");
                ioe.printStackTrace();
            }
        }*/

        String zoomLevel = "6.1";

        String imageSize = "200x200"; // "300x200";

        String locKey = "https://api.mapbox.com/styles/v1/mapbox/streets-v11/static/" +
                longitude + "," +
                latitude  + "," +
                zoomLevel + "/" +
                imageSize +
                "?access_token=pk.eyJ1Ijoic2llcnJhY3MiLCJhIjoiY2p2YWExN3NwMGQ3aTQxbzAxZnh6YzloMiJ9.BL6OLkhv0rHoKtMnL_kEkA";
        try
        {

            URL url = new URL(locKey);
            InputStream is = url.openStream();
            byte[] buffer = new byte[is.available()];
            is.read(buffer);

            File targetFile = new File("out/map.png");

            if (targetFile.exists())
            {
                targetFile.delete();
            }

            targetFile.createNewFile();

            OutputStream outStream = new FileOutputStream(targetFile, false);

            outStream.write(buffer);

            map = "out/map.png";
        }
        catch (MalformedURLException mue)
        {
            System.out.println("Malformed URL");
            mue.printStackTrace();
        }
        catch (IOException ioe)
        {
            System.out.println("IO Exception");
            ioe.printStackTrace();
        }

        return map;
    }

    public static void main(String[] args)
    {
        String keyword = "";
        Scanner in = new Scanner(System.in);
        System.out.print("Enter Your ZipCode: ");
        keyword = in.next();
        Weather w = new Weather(keyword);

        w.fetch();

        System.out.println(w.getTimeZone());
        System.out.println("Date/ Time: " + w.getTimeStamp());
        System.out.println("Current Temperature: " + w.getTemperature() +  " \u2109");
        System.out.println("Wind Gust: " + w.getWindSpeed()+ " MPH");
        System.out.println("Forecast: " + w.getWeather());
        System.out.println("Temperature in Celsius: " + w.getCelsius());
        System.out.println("icon is: " + w.getIcon());

    }
}

