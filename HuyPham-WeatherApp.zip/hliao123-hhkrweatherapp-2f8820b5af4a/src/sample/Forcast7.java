package sample;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;
import java.time.LocalDateTime;

public class Forcast7 {

    private String kwZip;
    private String city;
    private JsonElement forecast;



    public Forcast7(String kw) {
        try {
            kwZip = URLEncoder.encode(kw, "utf-8");
            city = URLEncoder.encode(kw, "utf-8");
        } catch (UnsupportedEncodingException uee) {
            uee.printStackTrace();
        }
    } // https://api.aerisapi.com/forecasts/95648?client_id=wQhXMMnxoRV4HNKoRLZrL&client_secret=lHCLaF7UAPs9hfLucn3ehMJr0SZpnjLPqx9G23hc


    public void fetch() {
        String key = "https://api.aerisapi.com/forecasts/"
                + kwZip
                + "?client_id=VHSQboCdrEwPFpuUTMYpk&client_secret=skRaav9bMvcI7J44GWZKh4BAptXAa0SxGHmLeWo6";

        try {
            URL url = new URL(key);
            InputStream is = url.openStream();
            InputStreamReader isr = new InputStreamReader(is);

            /*Parse JSON HERE*/

            forecast = JsonParser.parseReader(isr);
        } catch (MalformedURLException mue) {
            System.out.println("Malformed URL");
            mue.printStackTrace();
        } catch (IOException ioe) {
            System.out.println("IO Exception");
            ioe.printStackTrace();
        }


        /** set getter methods to retrieve from JSON api for the 7 day forecast*/
    }

    // Get maxTempF
    public String  getmaxTempF1(int num)
    {
        String maxF1 = "";
         maxF1 = forecast.getAsJsonObject()
                .get("response").getAsJsonArray()
                 .get(0).getAsJsonObject()
                .get("periods").getAsJsonArray()
                 .get(num).getAsJsonObject()
                 .get("maxTempF").getAsString();
        return maxF1;
    }

    // get max temp in celcius
    public String getmaxCelcius(int num)
    {
        String maxC1 = "";
        maxC1 = forecast.getAsJsonObject()
                .get("response").getAsJsonArray()
                .get(0).getAsJsonObject()
                .get("periods").getAsJsonArray()
                .get(num).getAsJsonObject()
                .get("maxTempC").getAsString();
        return maxC1;
    }


    // Get minTempF
    public String getminTempF1(int num)
    {
        String minF1 = "";
        minF1 = forecast.getAsJsonObject()
                .get("response").getAsJsonArray()
                .get(0).getAsJsonObject()
                .get("periods").getAsJsonArray()
                .get(num).getAsJsonObject()
                //.get("timestamp").getAsJsonObject()
                .get("minTempF").getAsString();
        return minF1;
    }

    //get min temp in celcius
    public String getminCelcius(int num)
    {
        String minC1 = "";
        minC1 = forecast.getAsJsonObject()
                .get("response").getAsJsonArray()
                .get(0).getAsJsonObject()
                .get("periods").getAsJsonArray()
                .get(num).getAsJsonObject()
                .get("minTempC").getAsString();
        return minC1;
    }

    // Get the time
    public String getTimeStamp(int num){
        long time = forecast.getAsJsonObject()
                .get("response").getAsJsonArray()
                .get(0).getAsJsonObject()
                .get("periods").getAsJsonArray()
                .get(num).getAsJsonObject()
                .get("timestamp").getAsLong();

        // Reformat the JSON
        long timestamp = time;
        SimpleDateFormat DateFormat = new SimpleDateFormat("EEE, d");
        String time1 = DateFormat.format(timestamp*1000L) ; // .format() need to use a String
        return time1;
    }

    // Get the weather
    public String getWeather(int num){
        return forecast.getAsJsonObject()
                .get("response").getAsJsonArray()
                .get(0).getAsJsonObject()
                .get("periods").getAsJsonArray()
                .get(num).getAsJsonObject()
                .get("weatherPrimary").getAsString();
    }

    // Get the icon
    public String getIcon(int num){
        return forecast.getAsJsonObject()
                .get("response").getAsJsonArray()
                .get(0).getAsJsonObject()
                .get("periods").getAsJsonArray()
                .get(num).getAsJsonObject()
                .get("icon").getAsString();
    }

    public static void main(String[] args)
    {
        /* To test the Forecast Class */
        String keyword = "";
        Scanner in = new Scanner(System.in);
        System.out.print("Enter Your ZipCode: ");
        keyword = in.next();
        Forcast7 w = new Forcast7(keyword);

        w.fetch();

        System.out.println("Max Temperture is: " + w.getmaxTempF1(1));
        System.out.println("Min Temperture is: " + w.getminTempF1(0));
        System.out.println("Today is: " + w.getTimeStamp(0));
        System.out.println(" max celcius: " + w.getmaxCelcius(0) + " and min is: " + w.getminCelcius(0));
    }
}