package sample;

public class getLocation {

    //https://maps.aerisapi.com/wQhXMMnxoRV4HNKoRLZrL_rUOW0GEyf5bT9JhUzro2WQAuUpj3A7nFHgVCRGEK/flat,radar,counties,interstates,admin-cities/256x256/Rocklin,CA,8/20191211195827_20191211195827.png





}
