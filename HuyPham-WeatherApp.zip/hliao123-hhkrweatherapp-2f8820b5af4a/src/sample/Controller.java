package sample;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.scene.Scene;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.skin.ComboBoxListViewSkin;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.ResourceBundle;


public class Controller implements Initializable {
    String kw;
    Weather w;
    Forcast7 f;
    Weather b;
    Boolean isF = true;
    Stage window;
    Scene scene;
    ComboBox<String> comboBox;
    // HashMap
    HashMap<String,String> hashMap = new HashMap<>();

    @FXML
    ComboBox kwField;

    @FXML
    Label dateNtime;


    @FXML
    ImageView background, logo, icon, mapicon;
    @FXML
    Label Time1;
    @FXML
    Label Time2;
    @FXML
    Label Time3;
    @FXML
    Label Time4;
    @FXML
    Label Time5;
    @FXML
    Label Time6;
    @FXML
    Label Time7;
    @FXML
    Button button;
    @FXML
    Label weatherData, weatherData1, weatherData2, weatherData3;

    @FXML
    Label MaxF1, MaxF2, MaxF3, MaxF4, MaxF5, MaxF6, MaxF7;
    @FXML
    Label MinF1, MinF2, MinF3, MinF4, MinF5, MinF6, MinF7;
    @FXML
    Label Wea1, Wea2, Wea3, Wea4, Wea5, Wea6, Wea7;
    @FXML
    ImageView icon1, icon2, icon3, icon4, icon5, icon6, icon7;
    @FXML
    Label LabelTime;





    public void initialize(URL url, ResourceBundle rb){
        // Explaination
        // Fixing the error with the space in the combo Box
        ComboBoxListViewSkin comboSkin = new ComboBoxListViewSkin(kwField);
        comboSkin.getPopupContent().addEventFilter(KeyEvent.ANY, (event) ->
        {
            if (event.getCode() == KeyCode.SPACE){
                event.consume();
            }
        });
        kwField.setSkin(comboSkin);
        hashMap.put("", ":auto");
    }
    public void handleToggleButton(ActionEvent e)
    {
        //boolean isF;
        if(isF) {
            isF = false;
            // set the text to show the celcius symbol
            button.setText("\u2103" );
            w.getCelsius();
            weatherData.setText(w.getCityState()+"\n"); // Location
                    weatherData1.setText("\t" + w.getCelsius() +  " \u2103\n"); //"Temperature
                        weatherData2.setText(w.getWindSpeed()+ " MPH\n"); //"Wind Gust:
                            weatherData3.setText(w.getWeather()); //"Forecast


            //changes the forecast text to celcius when toggle button is clicked
            MaxF1.setText(f.getmaxCelcius(0) +  " \u2103\n");
            MaxF2.setText(f.getmaxCelcius(1)+  " \u2103\n");
            MaxF3.setText(f.getmaxCelcius(2) +  " \u2103\n");
            MaxF4.setText(f.getmaxCelcius(3) +  " \u2103\n");
            MaxF5.setText(f.getmaxCelcius(4) +  " \u2103\n");
            MaxF6.setText(f.getmaxCelcius(5) +  " \u2103\n");
            MaxF7.setText(f.getmaxCelcius(6) +  " \u2103\n");
            // Set the label visible
            MaxF1.setVisible(true);
            MaxF2.setVisible(true);
            MaxF3.setVisible(true);
            MaxF4.setVisible(true);
            MaxF5.setVisible(true);
            MaxF6.setVisible(true);
            MaxF7.setVisible(true);

            // resets the minF to minimum celcius (minTempC)
            MinF1.setText(f.getminCelcius(0)+ "\u2103\n");
            MinF2.setText(f.getminCelcius(1)+ "\u2103\n");
            MinF3.setText(f.getminCelcius(2)+ "\u2103\n");
            MinF4.setText(f.getminCelcius(3)+ "\u2103\n");
            MinF5.setText(f.getminCelcius(4)+ "\u2103\n");
            MinF6.setText(f.getminCelcius(5)+ "\u2103\n");
            MinF7.setText(f.getminCelcius(6)+ "\u2103\n");
            // Set the label visible
            MinF1.setVisible(true);
            MinF2.setVisible(true);
            MinF3.setVisible(true);
            MinF4.setVisible(true);
            MinF4.setVisible(true);
            MinF5.setVisible(true);
            MinF6.setVisible(true);
            MinF7.setVisible(true);
        }
        else {
            isF = true;
            // sets the button to show the farenheit symbol
            button.setText("\u2109");
            //change back to Farenheit here

            weatherData.setText(w.getCityState()+"\n"); //"Location:
                weatherData1.setText(w.getTemperature() +  " \u2109\n"); //"Temperature:
                     weatherData2.setText(w.getWindSpeed()+ " MPH\n"); //"Wind Gust:
                        weatherData3.setText(w.getWeather()); //"Forecast:

            //changes the forecast text to celcius when toggle button is clicked
            MaxF1.setText(f.getmaxTempF1(0)+ "\u00B0F");
            MaxF2.setText(f.getmaxTempF1(1)+ "\u00B0F");
            MaxF3.setText(f.getmaxTempF1(2)+ "\u00B0F");
            MaxF4.setText(f.getmaxTempF1(3)+ "\u00B0F");
            MaxF5.setText(f.getmaxTempF1(4)+ "\u00B0F");
            MaxF6.setText(f.getmaxTempF1(5)+ "\u00B0F");
            MaxF7.setText(f.getmaxTempF1(6)+ "\u00B0F");
            // Set the label visible
            MaxF1.setVisible(true);
            MaxF2.setVisible(true);
            MaxF3.setVisible(true);
            MaxF4.setVisible(true);
            MaxF5.setVisible(true);
            MaxF6.setVisible(true);
            MaxF7.setVisible(true);

            // Show the minF
            MinF1.setText(f.getminTempF1(0)+ "\u00B0F");
            MinF2.setText(f.getminTempF1(1)+ "\u00B0F");
            MinF3.setText(f.getminTempF1(2)+ "\u00B0F");
            MinF4.setText(f.getminTempF1(3)+ "\u00B0F");
            MinF5.setText(f.getminTempF1(4)+ "\u00B0F");
            MinF6.setText(f.getminTempF1(5)+ "\u00B0F");
            MinF7.setText(f.getminTempF1(6)+ "\u00B0F");
            // Set the label visible only click the button
            MinF1.setVisible(true);
            MinF2.setVisible(true);
            MinF3.setVisible(true);
            MinF4.setVisible(true);
            MinF4.setVisible(true);
            MinF5.setVisible(true);
            MinF6.setVisible(true);
            MinF7.setVisible(true);
        }



        //=======================================================================

    }
    public void handleGoButton(ActionEvent e) {
        //Put hashMap on the search tool to allow we access get the weather both attitude, latitude and City Name
        kw = hashMap.get(kwField.getEditor().getText());
        /* Prints the location cordinates to console */
        // System.out.println("Test" + kw);
        w = new Weather(kw);
        w.fetch();


        try {
        weatherData.setText(w.getCityState() + "\n");//Location:

            weatherData1.setText(w.getTemperature() + " \u2109\n"); //Temperature:
        weatherData2.setText("Wind Speed " + w.getWindSpeed() + " MPH\n"); //Wind Gust:
        weatherData3.setText(w.getWeather()); //Forecast:

        }
        catch (Exception f) {

        }
        dateNtime.setText(w.getTimeStamp());

        //textArea - trying to set to white text
/*        weatherData.setStyle("-fx-text-inner-color: white");
        weatherData.setVisible(true);*/
        w.getIcon();

        icon.setImage(new Image("file:icons/" + w.getIcon()));
        icon.setVisible(true);

        //=======================================================================

        /**** Show the next days ****/
        f = new Forcast7(kw);
        f.fetch();

        Time1.setText(f.getTimeStamp(0));
        Time2.setText(f.getTimeStamp(1));
        Time3.setText(f.getTimeStamp(2));
        Time4.setText(f.getTimeStamp(3));
        Time5.setText(f.getTimeStamp(4));
        Time6.setText(f.getTimeStamp(5));
        Time7.setText(f.getTimeStamp(6));
        // Set the label visible only click the button
        Time1.setVisible(true);
        Time2.setVisible(true);
        Time3.setVisible(true);
        Time4.setVisible(true);
        Time5.setVisible(true);
        Time6.setVisible(true);
        Time7.setVisible(true);

        // Show the maxF
        MaxF1.setText(f.getmaxTempF1(0) + "\u00B0F");
        MaxF2.setText(f.getmaxTempF1(1) + "\u00B0F");
        MaxF3.setText(f.getmaxTempF1(2) + "\u00B0F");
        MaxF4.setText(f.getmaxTempF1(3) + "\u00B0F");
        MaxF5.setText(f.getmaxTempF1(4) + "\u00B0F");
        MaxF6.setText(f.getmaxTempF1(5) + "\u00B0F");
        MaxF7.setText(f.getmaxTempF1(6) + "\u00B0F");
        // Set the label visible only click the button
        MaxF1.setVisible(true);
        MaxF2.setVisible(true);
        MaxF3.setVisible(true);
        MaxF4.setVisible(true);
        MaxF5.setVisible(true);
        MaxF6.setVisible(true);
        MaxF7.setVisible(true);

        // Show the minF
        MinF1.setText(f.getminTempF1(0) + "\u00B0F");
        MinF2.setText(f.getminTempF1(1) + "\u00B0F");
        MinF3.setText(f.getminTempF1(2) + "\u00B0F");
        MinF4.setText(f.getminTempF1(3) + "\u00B0F");
        MinF5.setText(f.getminTempF1(4) + "\u00B0F");
        MinF6.setText(f.getminTempF1(5) + "\u00B0F");
        MinF7.setText(f.getminTempF1(6) + "\u00B0F");
        // Set the label visible only click the button
        MinF1.setVisible(true);
        MinF2.setVisible(true);
        MinF3.setVisible(true);
        MinF4.setVisible(true);
        MinF4.setVisible(true);
        MinF5.setVisible(true);
        MinF6.setVisible(true);
        MinF7.setVisible(true);


        // Show the Weather
        Wea1.setText(f.getWeather(0));
        Wea2.setText(f.getWeather(1));
        Wea3.setText(f.getWeather(2));
        Wea4.setText(f.getWeather(3));
        Wea5.setText(f.getWeather(4));
        Wea6.setText(f.getWeather(5));
        Wea7.setText(f.getWeather(6));
        // Set the label visible only click the button
        Wea1.setVisible(true);
        Wea2.setVisible(true);
        Wea3.setVisible(true);
        Wea4.setVisible(true);
        Wea5.setVisible(true);
        Wea6.setVisible(true);
        Wea7.setVisible(true);


        // Show the Icon
        Image img = new Image("file:icons/" + f.getIcon(0));
        icon1.setImage(img);
        Image img2 = new Image("file:icons/" + f.getIcon(1));
        icon2.setImage(img2);
        Image img3 = new Image("file:icons/" + f.getIcon(2));
        icon3.setImage(img3);
        Image img4 = new Image("file:icons/" + f.getIcon(3));
        icon4.setImage(img4);
        Image img5 = new Image("file:icons/" + f.getIcon(4));
        icon5.setImage(img5);
        Image img6 = new Image("file:icons/" + f.getIcon(5));
        icon6.setImage(img6);
        Image img7 = new Image("file:icons/" + f.getIcon(6));
        icon7.setImage(img7);
        // Set the label visible only click the button
        icon1.setVisible(true);
        icon2.setVisible(true);
        icon3.setVisible(true);
        icon4.setVisible(true);
        icon5.setVisible(true);
        icon6.setVisible(true);
        icon7.setVisible(true);


        //set map visible
        boolean visible = true;
        kw = kwField.getEditor().getText();
        w = new Weather(kw);
        w.fetch();
        String mapPath = w.getMap();
        /*isSuccesfull(true)*/
        mapicon.setImage(new Image("file:" + mapPath));
        mapicon.setVisible(true);

        if (visible = false) {
            mapicon.setVisible(false);
        }


    }
        //=======================================================================




    // code for map
    public void handleMapButton(ActionEvent e)
    {

        kw = kwField.getEditor().getText();
        w = new Weather(kw);
        w.fetch();
        String mapPath = w.getMap();

            mapicon.setImage(new Image("file:" + mapPath));
            mapicon.setVisible(true);

            /** Showing the current location **/
            button.fire();


    }

    public void startClock(){
        //TimeZone  = new TimeZone();
        b = new Weather(kw);
        b.fetch();
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            SimpleDateFormat timeFormatter = new SimpleDateFormat("hh:mm:ss s z");
            timeFormatter.setTimeZone(Weather.getTimeZone());
            String time = timeFormatter.format(new Date());
            LabelTime.setText(time);
            //timeFormatter.setTimeZone((currentWeather.getTimeZone()));
        }));

        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }

    /** MapBox and ComboBox**/
    public void handleAutoComplete(){
        // Check the length of the text
        if ( kwField.getEditor().getText().length() >= 1) {
            MapBox m = new MapBox(kwField.getEditor().getText());
            // Clear the old searchings to get better searchings
            kwField.getItems().clear();
            // Loop to check and get exactly searching
            for (int i = 0; i < m.getSize(); i++) {
                // Put the latitude and attitude into the HashMap
                hashMap.put(m.getmapBox(i), m.getCenter(i));
                kwField.getItems().add(m.getmapBox(i));
                //ComboBox combo_box = new ComboBox(FXCollections.observableArrayList(m));
                kwField.show();
            }
        }
    }




}
