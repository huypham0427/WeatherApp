package sample;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Clock {

/*    private void startClock(){
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            SimpleDateFormat timeFormatter = new SimpleDateFormat("hh:mm:ss s z");
            timeFormatter.setTimeZone(Weather.getTimeZone());
            String time = timeFormatter.format(new Date());
            LabelTime.setText(time);
            //timeFormatter.setTimeZone((currentWeather.getTimeZone()));
        }));

        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }*/
}
